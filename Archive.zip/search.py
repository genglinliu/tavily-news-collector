import pandas as pd
import os
from typing import Dict, Any
from tavily import TavilyClient
import json
from tqdm import tqdm
fake_news_domains_wiki = [
    "naturalnews.com", "healthimpactnews.com", "greenmedinfo.com", "mercola.com",
    "healthnutnews.com", "realfarmacy.com", "healthyholisticliving.com", "newstarget.com",
    "featureremedies.com", "medicalkidnap.com", "infowars.com", "wnd.com",
    "principia-scientific.com", "collective-evolution.com", "childrenshealthdefense.org",
    "truthkings.com", "goop.com", "foodbabe.com", "thetruthaboutcancer.com",
    "wakingtimes.com", "technocracy.news", "vaccineimpact.com",
    "stopmandatoryvaccination.com", "beforeitsnews.com", "bannedinfo.com",
    "preventdisease.com", "naturalsociety.com", "alternativemediasyndicate.com",
    "holistichealth.com", "prisonplanet.com", "banned.video", "brighteon.com",
    "yournewswire.com", "thepeoplesvoice.tv", "neonnettle.com", "newspunch.com",
    "americanews.com", "conservative101.com", "liberalsociety.com",
    "conservativebeaver.com", "torontotoday.net", "vancouvertimes.org",
    "denverguardian.com", "dailystormer.com", "gellerreport.com", "hoggwatch.com",
    "nationalfile.com", "trunews.com", "ancient-code.com", "dineal.com", "ewao.com",
    "galacticconnection.com", "geoengineeringwatch.org", "in5d.com",
    "responsibletechnology.org", "naturalblaze.com", "ripostelaique.com",
    "sciencevibe.com", "theasociatedpress.com", "cbs-news.us", "channel23news.com",
    "dailyviralbuzz.com", "now8news.com", "abcnews-us.com", "cnn-globalnews.com",
    "foxnews-us.com", "nbcnews11.com", "tmzbreaking.com", "viralspeech.com",
    "politicsfocus.com", "chicksonright.com", "climatedepot.com", "dailywire.com"
]

fake_news_domains_newsguard = ['unitynewsnetwork.co.uk', 'nationalvanguard.org', 'nationalvanguard.com', 'politikversagen.net', 'dailytelegraph.co.nz', 'whatdoesitmean.com', 'controinformazione.info', 'blacklistednews.com', 'aapsonline.org', 'rassegneitalia.org', 'rassegneitalia.info', 'frankspeech.com', 'zerohedge.com', 'salemnewschannel.com', 'ho1.us', 'humanrights.eadl.ir', 'wattsupwiththat.com', 'il-corrispondente.io', 'remnantnewspaper.com', 'geopoliticaleconomy.com', 'vaccineriskawareness.com', 'pravdareport.com', 'english.pravda.ru', 'persianepochtimes.com', 'kr.theepochtimes.com', 'epochtimestr.com', 'epochtimes.se', 'epochtimes.ru', 'pravda.ru', 'epochtimes-romania.com', 'epochtimes.pl', 'epochtimes.nl', 'epochtimes.jp', 'epochtimes.cz', 'epochtimes.com.ua', 'sott.net', 'covid19criticalcare.com', 'drsergegregoire.com', 'dilyana.bg', 'epochtimes.com.br', 'wnd.com', 'theepochtimes.com', 'epochtimes.com', 'everydayconcerned.net', 'cancerwisdom.net', 'qposts.online', 'operationq.pub', 'defendevropa.com', 'connectiv.events', 'dieunbestechlichen.com', 'impfkritik.de', 'thelastamericanvagabond.com', 'thelibertyloft.com', 'dailyclout.io', 'thebluestateconservative.com', 'tuckercarlson.com', 'mondialisation.ca', 'armedforces.press', 'journal-neo.su', 'nowtheendbegins.com', 'qalerts.app', 'qalerts.net', 'qalerts.pub', 'qanon.app', 'qdrop.pub', 'qposts.in', 'qanon.pub', 'vernoncoleman.org', 'pressenza.com', 'katehon.com', 'wddty.com', 'wakeup-world.com', 'europereloaded.com', 'qresear.ch', 'vernoncoleman.com', 'jimbakkershow.com', 'lesdeqodeurs.fr', 'bel.sputnik.by', 'big5.sputniknews.cn', 'br.sputniknews.com', 'cz.sputniknews.com', 'ir.sputniknews.com', 'jp.sputniknews.com', 'az.sputniknews.ru', 'lt.sputniknews.ru', 'oz.sputniknews-uz.com', 'pl.sputniknews.com', 'ro.sputnik.md', 'rs-lat.sputniknews.com', 'rs.sputniknews.com', 'ru.armeniasputnik.am', 'mundo.sputniknews.com', 'armeniasputnik.am', 'arabic.sputniknews.com', 'af.sputniknews.com', 'childrenshealthdefense.org', 'kopp-report.de', 'globalresearch.ca', 'redstate.com', 'redstatemail.com', 'presstv.com', 'americasfrontlinedoctors.org', 'aflds.org', 'americasfrontlinedoctorsummit.com', 'joehoft.com', 'lifenews.com', 'thewashingtonstandard.com', 'freedomplatform.tv', 'sputnikglobe.com', 'ru.sputnik.kg', 'freedomsphoenix.com', 'ru.sputnik.kz', 'sptnkne.ws', 'tr.sputniknews.com', 'uz.sputniknews.ru', 'vn.sputniknews.com', 'lifesitenews.com', '21stcenturywire.com', 'thegrayzone.com', 'tj.sputniknews.ru', 'contro.tv', 'anna-news.info', 'heartlanddailynews.com', 'vaccineshed.com', 'jbsvod.sardius.live', 'jimbakkershow.morningsidechurchinc.com', 'sputnik-tj.com', 'sputnik-ossetia.ru', 'sputnik-ossetia.com', 'sputnik-abkhazia.info', 'sputnik-abkhazia.ru', 'sputnik.az', 'sputnik.by', 'sputnik-georgia.com', 'sputnik-georgia.ru', 'sputnik.kg', 'sputnik.kz', 'sputnik.md', 'sputniknews.cn', 'sputniknews.com', 'sputniknews.gr', 'sputniknews.lt', 'sputniknewslv.com', 'sputniknews-uz.com', 'ru.sputnik.md', 'newstab.us']



FAKE_NEWS_DOMAINS = fake_news_domains_newsguard + fake_news_domains_wiki

class NewsSearch:

    def __init__(self, api_key: str = None):
        """Initialize with Tavily API key from environment variable or parameter."""
        self.api_key = api_key or os.getenv('TAVILY_API_KEY')
        if not self.api_key:
            raise ValueError("Please provide TAVILY_API_KEY as environment variable or parameter")
        self.client = TavilyClient(api_key=self.api_key)

    def search(self, query: str, include_domains: list[str] = None) -> Dict[str, Any]:
        """
        Perform a search prioritizing specific domains.
        
        Args:
            query: The search query string
            
        Returns:
            Dict containing search results
        """
        return self.client.search(
            query=query,
            include_domains=include_domains,
            max_results=20
        )

def print_results(results: Dict[str, Any]) -> None:
    """Print search results in a clean format."""
    print("\nSearch Results:")
    print("-" * 80)
    
    for result in results['results']:
        print(f"\nTitle: {result['title']}")
        print(f"URL: {result['url']}")
        print(f"Content: {result['content']}")
        print("-" * 80)

def enrich_claim_with_sources(searcher: NewsSearch, claim: str) -> Dict[str, Any]:
    """
    Enrich a claim with supporting and opposing sources by performing searches.
    
    Args:
        searcher: NewsSearch instance
        claim: The claim to search for
        
    Returns:
        Dict containing supporting_sources and opposing_sources
    """
    # Search reliable sources
    reliable_results = searcher.search(claim, include_domains=None)
    
    # Search potentially misleading sources
    misinfo_results = searcher.search(claim, include_domains=FAKE_NEWS_DOMAINS)
    
    # Format results into supporting and opposing sources
    supporting_sources = [
        {
            "title": result["title"],
            "url": result["url"],
            "content": result["content"]
        }
        for result in reliable_results["results"]  
    ]
    
    opposing_sources = [
        {
            "title": result["title"],
            "url": result["url"],
            "content": result["content"]
        }
        for result in misinfo_results["results"]  
    ]
    
    return {
        "supporting_sources": supporting_sources,
        "opposing_sources": opposing_sources
    }

def enrich_covid_data(input_file: str, output_file: str, api_key: str = None):
    """
    Read COVID data, enrich with sources, and append to output file as we go.
    
    Args:
        input_file: Path to input JSON file
        output_file: Path to output JSON file
        api_key: Optional Tavily API key
    """
    # Initialize search
    searcher = NewsSearch(api_key=api_key)
    
    # Read input data
    with open(input_file, 'r') as f:
        covid_data = json.load(f)
    
    # Create/clear output file with empty array
    with open(output_file, 'w') as f:
        f.write('[\n')
    
    # Process each claim and append to file
    for i, item in enumerate(tqdm(covid_data)):
        try:
            sources = enrich_claim_with_sources(searcher, item["claim"])
            item.update(sources)
            
            # Append to file with proper JSON formatting
            with open(output_file, 'a') as f:
                if i > 0:
                    f.write(',\n')
                json.dump(item, f, indent=4)
                
        except Exception as e:
            print(f"\nError processing claim: {item['claim']}")
            print(f"Error: {str(e)}")
            raise e
    
    # Close the JSON array
    with open(output_file, 'a') as f:
        f.write('\n]')
    
    print("\nCompleted processing all items")

if __name__ == "__main__":
    # Example usage
    input_file = "data/final-data/final_climate_data.json"
    output_file = "data/final-data/enriched_climate_data.json"
    api_key = "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"
    
    enrich_covid_data(input_file, output_file, api_key)
